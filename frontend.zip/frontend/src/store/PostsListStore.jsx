import { createContext, useReducer } from "react";

export const PostList = createContext({
  postList: [],
  addPost: () => { },
  deletePost: () => { }
})


// export const PostList = createContext(DEFAULT_CONTEXT);

const postListReducer = (currPostList, action) => {
  let newPostList = currPostList
  if (action.type === 'DELETE_POST') {
    newPostList = currPostList.filter(post => post.id !== action.payload.postId)
  }
  else if (action.type === 'ADD_POST') {
    newPostList = [action.payload, ...currPostList];
  }
  return newPostList
};




const PostListProvider = ({ children }) => {

  const [postList, dispatchPostList] = useReducer(postListReducer, DEFAULT_POST_LIST)
  // DEFAULT_POST_LIST

  const deletePost = (postId) => {
    dispatchPostList({
      type: 'DELETE_POST',
      payload: {
        postId,
      },
    });
    console.log(`This post called for delete ${postId}`)
  }


  const addPost = (userId, postname, postdescription, summary) => {
    dispatchPostList({
      type: 'ADD_POST',
      payload: {
        id: Date.now(),
        name: postname,
        description: postdescription,
        summary: summary,
        userId: userId,
      }
    })
  }


  return (
    <PostList.Provider value={
      {
        postList,
        addPost,
        deletePost
      }
    }>
      {children}
    </PostList.Provider>
  )
}

export default PostListProvider


const DEFAULT_POST_LIST = [{

  id: '1',
  name: 'Rama Krishna',
  description: 'A Loud popping sensation in knee, rapid swelling and Loss of range of motion and severe pain',
  summary: 'ACL Ligament tear and surgery needed',
  userId: 'user-9'
}, {
  id: '2',
  name: 'Pavan Narayan',
  description: 'A Visble deformed shoulder, swelling, intense pain and inablity to move a joint',
  summary: 'shoulder dislocation and surgery needed',
  userId: 'user-12'
},

];