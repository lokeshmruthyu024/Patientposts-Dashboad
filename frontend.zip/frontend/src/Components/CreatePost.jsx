import React, { useContext, useRef } from 'react'
import { PostList } from '../store/PostsListStore';

const CreatePost = () => {

  const { addPost } = useContext(PostList)

  const userIdElement = useRef();
  const postnameElement = useRef();
  const postdescriptionElement = useRef();
  const summaryElement = useRef();

  const Handlesubmit = (event) => {
    event.preventDefault();
    const userId = userIdElement.current.value;
    const postname = postnameElement.current.value;
    const postdescription = postdescriptionElement.current.value;
    const summary = summaryElement.current.value;

    userIdElement.current.value = ""
    postnameElement.current.value = ""
    postdescriptionElement.current.value = ""
    summaryElement.current.value = ""
    addPost(userId, postname, postdescription, summary);
  }

  return (
    <form className='create-post' onSubmit={Handlesubmit}>
      <div className="mb-3">
        <label htmlFor="userId" className='form-label'>Enter Patient Id here</label>
        <input type="text" ref={userIdElement} className="form-control" id="userId" placeholder="Enter Patient's Id" />
      </div>
      <div className="mb-3">
        <label htmlFor="name" className='form-label'>Patient's name</label>
        <input type="text" ref={postnameElement} className="form-control" id="name" placeholder="Mr. / Mrs." />
      </div>
      <div className="mb-3">
        <label htmlFor="description" className='form-label'>Patient's Description</label>
        <textarea type="text" ref={postdescriptionElement} rows={4} className="form-control" id="description" placeholder="Tell us about patient's case" />
      </div>
      <div className="mb-3">
        <label htmlFor="summary" className='form-label'>summary of the Patient</label>
        <input type="text" ref={summaryElement} className="form-control" id="summary" placeholder="summarize" />
      </div>
      <button type="submit" className="btn btn-primary">Post</button>
    </form>
  )
}

export default CreatePost
