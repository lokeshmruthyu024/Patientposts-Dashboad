import React from 'react'

import "bootstrap/dist/css/bootstrap.min.css"

const Footer = () => {
  return (
    <div>
      <footer className="py-3 my-4">
        <p className="text-center text-muted">© 2024 Patient Management System, Inc</p>
        <p className="text-center text-muted">All Rights Reserved</p>
      </footer>
    </div>
  )
}

export default Footer
