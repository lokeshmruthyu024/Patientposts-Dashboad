import React from 'react'

const Welcomemessage = () => {
  return (
    <center>
      <h1 className='welcome-message'>There are no cases left in a Queue</h1>
    </center>
  )
}

export default Welcomemessage
